let contacts = [];

function addContact() {
    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const email = document.getElementById("email").value;

    if (name && phone && email) {
        const contact = { name, phone, email };
        contacts.push(contact);
        displayContacts();
        clearForm();
    } else {
        alert("Please fill out all fields.");
    }
}

function displayContacts() {
    const contactDisplay = document.getElementById("contactDisplay");
    contactDisplay.innerHTML = "";
    contacts.forEach((contact, index) => {
        const contactItem = document.createElement("li");
        contactItem.classList.add("contact-item");
        contactItem.innerHTML = `
            <span>${contact.name} - ${contact.phone} - ${contact.email}</span>
            <button onclick="deleteContact(${index})">Delete</button>
        `;
        contactDisplay.appendChild(contactItem);
    });
}

function deleteContact(index) {
    contacts.splice(index, 1);
    displayContacts();
}

function clearForm() {
    document.getElementById("name").value = "";
    document.getElementById("phone").value = "";
    document.getElementById("email").value = "";
}
